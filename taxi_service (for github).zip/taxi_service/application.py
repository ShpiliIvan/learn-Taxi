import re

import flask as f

import database.mongodb
import database.postgresql


application = f.Flask(__name__)

application.config['SECRET_KEY'] = "/YDXvEb%_}=f-8='Y?Uz;t_MazqUKJ"


@application.route('/')
def home():

    postgresql = database.postgresql.PostgreSQL.get(f.g)
    mongodb = database.mongodb.MongoDB.get(f.g)

    if 'language' not in f.session:
        f.session['language'] = 'ru'

    return f.render_template(
        'home.html',
        languages=mongodb.read('languages')[0], tab=mongodb.read('tab')[0], pages=mongodb.read('pages'),
        best_drivers=postgresql.get_best_drivers()
    )


@application.route('/register', methods=['GET', 'POST'])
def register():

    postgresql = database.postgresql.PostgreSQL.get(f.g)
    mongodb = database.mongodb.MongoDB.get(f.g)

    pages = mongodb.read('pages')

    if f.request.method == 'POST':

        if re.fullmatch("[a-zA-Z_][a-zA-Z0-9_]*", f.request.form.get('nickname')) is None:
            return f"<h3> {pages[3]['registration']['flashes']['invalid_nickname'][f.session['language']]} </h3>"

        if re.fullmatch("([a-zA-Z]*)|([а-яА-Я]*)", f.request.form.get('first_name')) is None:
            return f"<h3> {pages[3]['registration']['flashes']['invalid_first_name'][f.session['language']]} </h3>"

        if re.fullmatch("([a-zA-Z]*)|([а-яА-Я]*)", f.request.form.get('last_name')) is None:
            return f"<h3> {pages[3]['registration']['flashes']['invalid_last_name'][f.session['language']]} </h3>"

        if re.fullmatch("(.{0})|([+][0-9]{10,13})", f.request.form.get('phone')) is None:
            return f"<h3> {pages[3]['registration']['flashes']['invalid_phone'][f.session['language']]} </h3>"

        if re.fullmatch("[a-zA-Z_.]+@[a-z]+[.][a-z]+", f.request.form.get('email')) is None:
            return f"<h3> Invalid E-mail </h3>"

        if f.request.form.get('password') != f.request.form.get('password_confirmation'):
            return f"<h3> {pages[3]['registration']['flashes']['different_passwords'][f.session['language']]} </h3>"

        postgresql.create_user(
            f.request.form.get('nickname'),
            f.request.form.get('first_name'), f.request.form.get('last_name'),
            f.request.form.get('phone'), f.request.form.get('email'),
            f.request.form.get('password')
        )

        return f.redirect(f.url_for('home'))

    if 'language' not in f.session:
        f.session['language'] = 'ru'

    return f.render_template(
        'register.html',
        languages=mongodb.read('languages')[0], tab=mongodb.read('tab')[0], pages=pages,
    )


@application.route('/driver/<int:_id>')
def show_driver(_id):

    postgresql = database.postgresql.PostgreSQL.get(f.g)
    mongodb = database.mongodb.MongoDB.get(f.g)

    postgresql.update_driver_views(_id)

    positives = postgresql.get_driver_reviews(_id, 'positive')
    neutrals = postgresql.get_driver_reviews(_id, 'neutral')
    negatives = postgresql.get_driver_reviews(_id, 'negative')

    reviews = positives + neutrals + negatives

    views = postgresql.get_driver_views(_id)

    driver = postgresql.get_driver_statistics(_id)

    driver.update(
        {'views': views, 'reviews': reviews, 'positives': positives, 'neutrals': neutrals, 'negatives': negatives}
    )

    return f.render_template(
        'driver.html',
        languages=mongodb.read('languages')[0], tab=mongodb.read('tab')[0], pages=mongodb.read('pages'),
        driver=driver, _id=_id
    )


@application.route('/switch-language/<language>')
def switch(language):

    f.session['language'] = language

    return f.redirect(f.url_for('home'))


@application.teardown_appcontext
def close_database_connection(ex):

    postgresql, mongodb = f.g.pop('postgresql', None), f.g.pop('mongodb', None)

    if postgresql is not None:
        postgresql.close()

    if mongodb is not None:
        mongodb.close()


application.run(debug=False)

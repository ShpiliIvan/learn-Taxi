from pymongo import MongoClient


class MongoDB:

    def __init__(self, CONNECTION_STRING, DATABASE):

        self.client = MongoClient(CONNECTION_STRING)
        self.database = self.client[DATABASE]

    def read(self, collection):
        return list(self.database[collection].find({}, {'_id': 0}))

    def close(self):
        self.client.close()

    @staticmethod
    def get(g):

        if 'mongodb' not in g:

            g.mongodb = MongoDB(
                "mongodb+srv://taxi_service:mongodb@cluster0.vbnsp.mongodb.net/test", "taxi_service"
            )

        return g.mongodb

import psycopg2
import psycopg2.extras

from werkzeug.security import generate_password_hash


class PostgreSQL:

    def __init__(self, HOST, PORT, USER, PASSWORD, DATABASE):

        self.HOST, self.PORT, self.USER, self.PASSWORD, self.DATABASE = HOST, PORT, USER, PASSWORD, DATABASE
        self.conn = None

    def connect(self):
        self.conn = psycopg2.connect(
            host=self.HOST, port=self.PORT, user=self.USER, password=self.PASSWORD, dbname=self.DATABASE
        )

    def close(self):
        self.conn.close()

    @staticmethod
    def get(g):

        if 'postgresql' not in g:

            g.psqldb = PostgreSQL(
                "abul.db.elephantsql.com", 5432, "qgzyiktw", "O83AcmVAShYmDXOg9V2LuyLbcUQVP7hA", "qgzyiktw"
            )

            g.psqldb.connect()

        return g.psqldb

    def get_best_drivers(self):

        with self.conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cursor:

            cursor.execute('SELECT * FROM best_drivers;')

            return cursor.fetchall()

    def create_user(self, nickname, first_name, last_name, phone, email, password):

        with self.conn.cursor() as cursor:

            hashed = generate_password_hash(password, salt_length=8)

            cursor.execute(
                'INSERT INTO "user" (nickname, first_name, last_name, email, phone, password) '
                'VALUES (%s, %s, %s, %s, %s, %s);', (nickname, first_name, last_name, email, phone, hashed)
            )

            self.conn.commit()

    def get_driver_statistics(self, _id):

        with self.conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cursor:

            cursor.execute('SELECT * FROM driver_statistics WHERE id = (%s);', (_id,))

            data = cursor.fetchall()

        return data[0] if data else None

    def get_driver_reviews(self, uid, rtype):

        with self.conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cursor:

            cursor.execute(
                'SELECT d.id FROM "user" u INNER JOIN driver d ON u.driver_id = d.id WHERE u.id = (%s);', (uid,)
            )

            did = cursor.fetchall()[0]['id']

            cursor.execute('SELECT * FROM count_driver_reviews(%s, %s)', (did, rtype))

            data = cursor.fetchall()

        return data[0]['number'] if data else 0

    def get_driver_views(self, uid):

        with self.conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cursor:

            cursor.execute(
                'SELECT d.views FROM "user" u INNER JOIN driver d ON u.driver_id = d.id WHERE u.id = (%s);', (uid,)
            )

            return cursor.fetchall()[0]['views']

    def update_driver_views(self, uid):

        with self.conn.cursor() as cursor:

            cursor.execute(
                'SELECT d.id FROM "user" u INNER JOIN driver d ON u.driver_id = d.id WHERE u.id = (%s);', (uid,)
            )

            did = cursor.fetchall()[0][0]

            cursor.execute('CALL update_views(%s)', (did,))

            self.conn.commit()

